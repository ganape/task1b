# Chest_x_ray_Detection

In this project I have created pneumonia predictor and it will show
If the person is infected by pneumonia as this is very importent for ud in day to day life
because of this pendamic 

thank you  